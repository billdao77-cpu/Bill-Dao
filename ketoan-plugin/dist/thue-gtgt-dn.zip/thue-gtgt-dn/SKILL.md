---
name: thue-gtgt-dn
description: Tính và chuẩn bị số liệu khai thuế GTGT cho doanh nghiệp nhỏ và vừa năm 2026 — phương pháp khấu trừ (đầu ra trừ đầu vào đủ điều kiện, thuế còn được khấu trừ chuyển kỳ sau) hoặc trực tiếp theo tỷ lệ % doanh thu (1%, 3%, 5%, 2%); loại hóa đơn từ 5 triệu trả tiền mặt (kể cả cộng dồn cùng người bán cùng ngày), giảm thuế suất 8% đến 31/12/2026, kỳ khai tháng hay quý (doanh thu năm trước 50 tỷ), hạn nộp, bút toán khấu trừ 33311/1331, khai bổ sung, hoàn thuế. Dùng khi người dùng hỏi "tính thuế GTGT quý này", "tờ khai 01/GTGT", "thuế VAT phải nộp bao nhiêu", "hóa đơn trả tiền mặt có được khấu trừ không", "còn được khấu trừ chuyển kỳ sau", "thuế suất 8% hay 10%", "khai thuế tháng hay quý".
---

# Thuế GTGT doanh nghiệp

Đọc `references/nguyen-tac-chung.md`, `references/thue-dn-2026.md` (mục 1, 6, 7); căn cứ ở `references/van-ban-hieu-luc.md`.

## 1. Xác định

- Phương pháp (Luật 48/2024 Đ.11–12): **khấu trừ** nếu doanh thu năm từ 1 tỷ trở lên và làm đủ sổ sách, hoặc DN tự nguyện đăng ký; **trực tiếp theo doanh thu** nếu doanh thu năm dưới 1 tỷ và chưa đăng ký tự nguyện khấu trừ. TNDN theo % doanh thu không làm mất quyền khấu trừ GTGT.
- Kỳ khai: quý (doanh thu năm trước ≤50 tỷ, DN mới) / tháng (>50 tỷ) – [cần kiểm tra NĐ 252/2026]. Hạn: tháng → ngày 20 tháng sau; quý → ngày cuối tháng đầu quý sau; trùng ngày nghỉ lùi sang ngày làm việc tiếp theo.
- Năm 2026, DN nhỏ, siêu nhỏ: kiểm tra **gia hạn nộp tiền** GTGT theo NĐ 245/2026 (`references/thue-dn-2026.md` mục 6a) – chỉ lùi hạn nộp tiền, không lùi hạn tờ khai; đề nghị gia hạn gửi chậm nhất 02/11/2026.
- Số thuế còn được khấu trừ kỳ trước (chỉ tiêu chuyển sang trên tờ khai kỳ trước).

## 2. Tính

Khấu trừ – lấy bảng kê từ skill `doc-hoa-don-xml` (`--csv`), thêm cột `thanh_toan` (CK/TM) và `loai_tru` nếu cần:

```bash
python3 scripts/tinh_gtgt.py bang_ke_q3.csv --con-khau-tru-ky-truoc 12000000
```

Trực tiếp:

```bash
python3 scripts/tinh_gtgt.py --truc-tiep hang-hoa=2400000000 dich-vu=300000000 --giam-20
```

## 3. Quy tắc phải nói đúng

- Hóa đơn mua vào **từ 5 triệu** (giá đã có thuế; nhiều hóa đơn cùng người bán cùng ngày cộng lại) phải có **chứng từ thanh toán không dùng tiền mặt** mới được khấu trừ (Luật 48/2024 Đ.14 k.2 điểm b; ngưỡng 5 triệu tại NĐ 181/2025 Đ.26 – TC); trước 01/07/2025 là 20 triệu. Thuế GTGT của khoản này **cũng không được tính vào chi phí** (Đ.14 k.1 điểm e).
- Thuế suất **8%** chỉ cho nhóm được giảm, đến **31/12/2026** (NĐ 174/2025); loại trừ viễn thông, tài chính, ngân hàng, chứng khoán, bảo hiểm, BĐS, kim loại, khai khoáng, hàng chịu TTĐB. Sau 31/12/2026 kiểm tra có gia hạn không.
- Đầu vào dùng chung cho hoạt động chịu thuế và không chịu thuế, không hạch toán riêng được: khấu trừ theo tỷ lệ doanh thu chịu thuế / tổng doanh thu (Đ.14 k.1 điểm b). DN doanh thu dưới 1 tỷ mua vào nhiều có thuế: gợi ý cân nhắc đăng ký tự nguyện khấu trừ (Đ.11 k.2 điểm b).
- Khai sai: tự khai bổ sung, nộp đủ tiền thuế + tiền chậm nộp 0,03%/ngày **trước khi** có quyết định kiểm tra → không bị phạt khai sai (Luật 108/2025 Đ.44 k.2 điểm a).
- Hoàn thuế GTGT (xuất khẩu, dự án đầu tư…): điều kiện riêng – nêu nguyên tắc, chuyển người hành nghề.
- Mẫu tờ khai: **01/GTGT theo TT 89/2026** cho kỳ tính thuế từ 01/7/2026 (kỳ trước đó dùng mẫu TT 80/2021). Chỉ tiêu chính: [22] còn khấu trừ kỳ trước; [23], [24] giá trị và thuế mua vào (hóa đơn hợp lệ, kể cả hóa đơn không được khấu trừ); [25] thuế được khấu trừ; [26] không chịu thuế; [29] 0%; [30], [31] 5%; [32], [33] 10% – **hàng giảm còn 8% khai chung vào [32]**, [33] = [32] × 10% − thuế được giảm, kèm phụ lục giảm thuế (Mẫu 01, Phụ lục III NĐ 174/2025); [36] = [35] − [25]; [37], [38] điều chỉnh (mua trả chậm từ 5 triệu không trả bằng chuyển khoản → khai giảm [37] kỳ đến hạn thanh toán); [40a] = [36] − [22] + [37] − [38] − [39a]; [43] chuyển kỳ sau. Không tự điền thay người dùng trên eTax.

## 4. Đầu ra

**File Word "Hướng dẫn điền tờ khai thuế GTGT"** (đầu ra chính) bằng `python3 scripts/huong_dan_to_khai.py bang_ke.csv --ky 10/2026 --con-khau-tru-ky-truoc 1850000 --ten "..." --mst ... --nhac "việc kỳ sau" --ra huong-dan.docx`. Bảng kê CSV lấy từ skill `doc-hoa-don-xml` (`--csv`), thêm cột `thanh_toan` (CK/TM, theo sổ quỹ, sao kê), `loai_tru` (`x` = không được khấu trừ; `khong_hop_le` = hóa đơn trùng, sai MST người mua – không đưa vào tờ khai kỳ này), `ly_do` (1 dòng) và các dòng bán ra có `tsuat`. File gọn, không thừa:
1. Bảng chỉ tiêu cần điền: chỉ tiêu – nội dung – số điền – lấy từ đâu (chỉ tiêu khác để trống).
2. Phụ lục giảm thuế (nếu có hàng 8%).
3. Hóa đơn mua vào cần lưu ý: cách khai, lý do, việc cần làm.
4. Hạn nộp tờ khai và tiền (tự xét gia hạn NĐ 245/2026; hạn trùng thứ Bảy, Chủ nhật lùi sang thứ Hai – ngày lễ đối chiếu thêm).
5. Kỳ sau nhớ.

Thiếu số liệu (thuế còn khấu trừ kỳ trước, cách thanh toán hóa đơn từ 5 triệu) thì hỏi người dùng, không tự giả định. Bút toán (Nợ 33311 / Có 1331; nộp thuế Nợ 33311 / Có 112) và lịch cả năm (skill `lich-thue-dn`) chỉ đưa khi người dùng hỏi. Câu chốt: "Đối chiếu tờ khai trên HTKK/eTax trước khi nộp."

<!-- KET-NOI:BAT-DAU (sinh tự động từ scripts/ket_noi.json – sửa ở đó rồi chạy build) -->
## Kết nối ứng dụng

Connector dùng cho skill này: **Google Drive** · **Gmail** · **Google Calendar** · **Microsoft 365 (Outlook, OneDrive/SharePoint, Teams)**. Đọc quy tắc trong `references/ket-noi.md` trước khi dùng.

1. Lấy bảng kê hóa đơn mua vào/bán ra (từ skill `doc-hoa-don-xml` hoặc file trên Drive) để tính số liệu tờ khai.
2. Tạo nhắc hạn nộp tờ khai và nộp tiền (ngày 20 hằng tháng hoặc ngày cuối tháng đầu quý sau) trên lịch.
3. Lưu bảng tính số liệu tờ khai vào Drive.

**Khi chưa kết nối:** làm đủ phần soạn thảo, tính toán; đưa nội dung sẵn để người dùng tự dán vào email, lịch, thư mục; nhắc **một lần** cách bật connector, không dừng việc chỉ vì chưa kết nối.
<!-- KET-NOI:KET-THUC -->
