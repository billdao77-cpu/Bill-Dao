---
name: so-sanh-phien-ban
description: So sánh hai phiên bản hợp đồng hoặc văn bản (bản mình gửi và bản đối tác sửa lại, bản nháp cũ và mới, hợp đồng năm trước và năm nay, điều khoản giao dịch chung cũ và mới) bằng công cụ so sánh theo đoạn trên file Word/PDF/văn bản dán vào — liệt kê mọi chỗ sửa, thêm, xóa theo từng Điều, đánh dấu thay đổi nhạy cảm (số tiền, tỷ lệ, thời hạn, chữ "không", phạt, chấm dứt, thanh toán, cơ quan giải quyết tranh chấp, giới hạn trách nhiệm), phát hiện sửa "lén" không báo, đánh giá thay đổi có lợi hay bất lợi cho bên người dùng. Dùng khi người dùng nói "so sánh 2 bản hợp đồng", "đối tác sửa những gì", "bản mới khác bản cũ chỗ nào", "kiểm tra họ có sửa thêm gì không", "đối chiếu phiên bản".
---

# So sánh phiên bản

Đọc trước: `references/nguyen-tac-chung.md`, `references/playbook-dieu-khoan.md`.

## Quy trình
1. Xác định bản nào là **cũ/gốc**, bản nào **mới**; người dùng là bên nào.
2. Chạy `so_sanh_van_ban` (`ban_cu`, `ban_moi` là đường dẫn .docx/.pdf/.txt; hoặc `van_ban_cu`, `van_ban_moi`). Dòng lệnh: `python3 scripts/cong_cu.py so_sanh_van_ban ban_cu=v1.docx ban_moi=v2.docx`. PDF scan → OCR trước.
3. Đọc từng thay đổi; với đoạn bị **Sửa**, đọc cả đoạn trước – sau để hiểu ngữ cảnh (công cụ so theo đoạn, có thể bỏ sót khi đoạn bị tách/gộp).
4. Đánh giá từng thay đổi: `Có lợi cho bạn / Bất lợi / Trung tính`, mức `🔴/🟡/🔵`.
5. Nếu đối tác gửi kèm "danh sách sửa đổi" (cover note) → đối chiếu: thay đổi nào **không được nêu trong danh sách** → đánh dấu "SỬA KHÔNG BÁO".

## Đầu ra
Sau khi đánh giá xong, chốt với người dùng quyết định từng thay đổi (Chấp nhận / Không chấp nhận / Đề nghị sửa / Đề nghị bổ sung), rồi xuất bằng `bang_gop_y_hop_dong` (`python3 scripts/cong_cu.py bang_gop_y_hop_dong duong_dan_ra=y-kien.docx ten_hop_dong="..." ben_toi="..." doi_tac="..." ngay_ban_doi_tac=... ban_goc="ngày ..." han_phan_hoi=... thay_doi='[...]' thieu='[...]'`). Công cụ ghi **2 file tách riêng**:
1. `<tên>_gui-doi-tac.docx` – **Bảng ý kiến gửi đối tác**: mỗi dòng 1 Điều: nội dung đối tác đề xuất, ý kiến của ta (lý do ngắn chỉ khi có lợi cho đàm phán, vd viện dẫn luật), câu chữ đề nghị. Không có đánh giá rủi ro, không lộ phương án nhượng bộ.
2. `<tên>_noi-bo.docx` – **Trình duyệt nội bộ**: thay đổi cũ → mới, sửa không báo, mức rủi ro, đề xuất, căn cứ một dòng, thông tin còn thiếu, ô giám đốc duyệt.

Câu chữ đề nghị viết sẵn để chép vào hợp đồng. Thông tin chưa có (bên mình là bên nào, giá trị lô hàng, phương án sếp chấp nhận) → ghi vào `thieu`, không tự giả định. Trả lời trong chat chỉ cần: số thay đổi, số sửa không báo, 2 file đã tạo.

## Lưu ý
- Thay đổi nhỏ nguy hiểm thường gặp: "và" ↔ "hoặc"; "phải" ↔ "có thể"; thêm/bỏ "không"; "ngày" ↔ "ngày làm việc"; "kể từ ngày ký" ↔ "kể từ ngày nhận hóa đơn"; bỏ trần phạt; đổi Trọng tài ↔ Tòa án; đổi địa điểm giải quyết tranh chấp; thêm "tự động gia hạn".
- Bảng, phụ lục: công cụ đọc bảng trong .docx thành dòng; kiểm tra lại bằng mắt bảng giá, bảng thông số.
- Không ghi đè file nào; muốn bản "đã chấp nhận thay đổi" → tạo file mới.

<!-- KET-NOI:BAT-DAU (sinh tự động từ scripts/ket_noi.json – sửa ở đó rồi chạy build) -->
## Kết nối ứng dụng

Connector dùng cho skill này: **Google Drive** · **Gmail** · **Microsoft 365 (Outlook, OneDrive/SharePoint, Teams)**. Đọc quy tắc trong `references/ket-noi.md` trước khi dùng.

1. Lấy hai phiên bản từ Drive (lịch sử phiên bản hoặc hai file) hoặc từ hai thư: bản mình gửi đi và bản đối tác gửi lại.
2. Lưu bảng so sánh thay đổi vào Drive; tạo nháp email hỏi lại đối tác về các chỗ "sửa không báo".

**Khi chưa kết nối:** làm đủ phần soạn thảo, tính toán; đưa nội dung sẵn để người dùng tự dán vào email, lịch, thư mục; nhắc **một lần** cách bật connector, không dừng việc chỉ vì chưa kết nối.
<!-- KET-NOI:KET-THUC -->
